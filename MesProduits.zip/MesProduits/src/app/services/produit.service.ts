
import { Injectable } from '@angular/core';
import { Produit } from '../model/produit.model';
import { Categorie } from '../model/categorie.model';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '../../environments/environment';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable({
  providedIn: 'root',
})
export class ProduitService {

  produits!: Produit[];
  produit!: Produit;
  categories!: Categorie[];

  constructor(private http: HttpClient) {}

  listeProduit(): Observable<Produit[]> {
    return this.http.get<Produit[]>(environment.apiURL);
  }

  ajouterProduit(prod: Produit): Observable<Produit> {
    return this.http.post<Produit>(environment.apiURL, prod, httpOptions);
  }

  supprimerProduit(id: string): Observable<void> {
    const url = `${environment.apiURL}/${id}`;
    return this.http.delete<void>(url);
  }

  consulterProduit(id: string): Observable<Produit> {
    const url = `${environment.apiURL}/${id}`;
    return this.http.get<Produit>(url);
  }

  listeCategories(): Observable<Categorie[]> {
    return this.http.get<Categorie[]>('http://localhost:8090/cat');
  }

  consulterCategorie(id: number): Categorie {
    return this.categories.find(cat => cat.idCat == id)!;
  }

  updateProduit(prod: Produit): Observable<Produit> {
    const url = `${environment.apiURL}/${prod.id}`;
    return this.http.put<Produit>(url, prod, httpOptions);
  }
}
