import { Categorie } from "./categorie.model";

export class Produit {
  id!: string;
  idProduit!: number;
  nomProduit!: string;
  prixProduit!: number;
  dateCreation!: Date;
  idCat!: number;
  categorie!: any;
}
