
import { Component, OnInit } from '@angular/core';
import { Produit } from '../model/produit.model';
import { ActivatedRoute, Router } from '@angular/router';
import { ProduitService } from '../services/produit.service';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-update-produit',
  standalone: true,
  imports: [FormsModule, CommonModule],
  templateUrl: './update-produit.component.html',
  styles: ``,
})
export class UpdateProduitComponent implements OnInit {

  currentProduit = new Produit();

  constructor(
    private activatedRoute: ActivatedRoute,
    private router: Router,
    private produitService: ProduitService
  ) {}

  ngOnInit(): void {
    const id = this.activatedRoute.snapshot.params['id'];

    this.produitService.consulterProduit(id).subscribe({
      next: (prod) => {
        this.currentProduit = prod;
      },
      error: (err) => {
        console.log(err);
      }
    });
  }

  updateProduit() {
    this.produitService.updateProduit(this.currentProduit).subscribe({
      next: () => {
        console.log('Produit modifié');
        this.router.navigate(['produits']);
      },
      error: (err) => {
        console.log(err);
      }
    });
  }
}
