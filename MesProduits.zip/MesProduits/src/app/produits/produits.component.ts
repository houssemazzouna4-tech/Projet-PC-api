
import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { Produit } from '../model/produit.model';
import { ProduitService } from '../services/produit.service';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-produits',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './produits.component.html',
  styleUrl: './produits.component.css'
})
export class ProduitsComponent implements OnInit {

  produits!: Produit[];

  constructor(private produitService: ProduitService) {}

  ngOnInit() {
    this.chargerProduits();
  }

  chargerProduits() {
    this.produitService.listeProduit().subscribe(prods => {
      this.produits = prods;
    });
  }

  supprimerProduit(p: Produit) {
    let conf = confirm("Etes-vous sûr ?");

    if (conf) {
      this.produitService.supprimerProduit(p.id).subscribe({
        next: () => {
          console.log("Produit supprimé");
          this.chargerProduits();
        },
        error: (err) => {
          console.log(err);
        }
      });
    }
  }
}
